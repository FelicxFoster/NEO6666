#include <ros/ros.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>
#include <cmath>
typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

class RobotPose
{
public:
	int target_order;
	int positionx[2],positiony[2];
	bool send_flag;
	RobotPose()
	{
		sub_ = n_.subscribe("amcl_pose",100,&RobotPose::poseCallback,this);
		positionx[0]=-0.4940;
		positiony[0]=-0.0756;
		positionx[1]=-1.3411;
		positiony[1]=-0.4067;
		target_order=0;
		send_flag=true;
	}

	void poseCallback(const geometry_msgs::PoseWithCovarianceStamped::ConstPtr &msg)		
	{
		std_msgs::Header header=msg->header;
		geometry_msgs::Point current_pos=msg->pose.pose.position;
		ROS_INFO("Time: %f",(double)header.stamp.toSec());
		ROS_INFO("Listener: current position is x=%f y=%f",current_pos.x,current_pos.y);
		double distance;
		distance=sqrt(
		(current_pos.x-positionx[target_order])*(current_pos.x-positionx[target_order])
	 -(current_pos.y-positiony[target_order])*(current_pos.y-positiony[target_order]));
	 	if(distance<0.1)
	 	{
	 		target_order+=target_order<2?1:0;
	 		send_flag=true;
	 	}
	}
private:
	ros::NodeHandle n_; 
	ros::Subscriber sub_;
}; 
int main(int argc,char** argv){
	ros::init(argc,argv,"pose_listener");
	RobotPose RbObject;

	MoveBaseClient ac("move_base", true);
  while(!ac.waitForServer(ros::Duration(5.0))){
    ROS_INFO("Waiting for the move_base action server to come up");
  }

	move_base_msgs::MoveBaseGoal goal;
	goal.target_pose.header.frame_id = "map";
	goal.target_pose.pose.orientation.w = 1.0;
	ros::Rate loop_rate(1.0);                 //创建 rate 对象，定义循环发布的频率，1 HZ
	while(ros::ok()){                         //只要没有关闭，一直循环
				
		goal.target_pose.header.stamp = ros::Time::now();
		goal.target_pose.pose.position.x = RbObject.positionx[RbObject.target_order];
		goal.target_pose.pose.position.y = RbObject.positiony[RbObject.target_order];
		if(RbObject.send_flag)
		{
			ac.sendGoal(goal);
			RbObject.send_flag=false;
		}		
		loop_rate.sleep();                     //根据定义的发布频率，sleep
	}

	ros::spin();
	return 0;
}

