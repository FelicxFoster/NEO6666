#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>
#include "tf/transform_broadcaster.h"
#include "tf/transform_listener.h"
#include "tf/message_filter.h"
#include "tf/tf.h"
#include "cmath"
#include "message_filters/subscriber.h"


typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

void init_goalList(std::vector<geometry_msgs::Pose> &pose_list)
{
	//Create a list to hold the target quaternions (orientations)
	geometry_msgs::Quaternion quaternions;
	geometry_msgs::Point point;

	point = setPoint(0.995, 0.008, 0.000);
	quaternions = setQuaternion( 1.573 );
	pose_list[0].position = point;
	pose_list[0].orientation = quaternions;

	point = setPoint(1.013, 1.011, 0.000);
	quaternions = setQuaternion( -3.123  );
	pose_list[1].position = point;
	pose_list[1].orientation = quaternions;

	point = setPoint(0.000, 1.019, 0.000);
	quaternions = setQuaternion( -1.576 );
	pose_list[2].position = point;
	pose_list[2].orientation = quaternions;

	point = setPoint(0.008, 0.001, 0.000);
	quaternions = setQuaternion( -0.003 );
	pose_list[3].position = point;
	pose_list[3].orientation = quaternions;
}

geometry_msgs::Point setPoint(double _x, double _y, double _z)
{
	geometry_msgs::Point m_point;
	m_point.x = _x;
	m_point.y = _y;
	m_point.z = _z;
	return m_point;
}

geometry_msgs::Quaternion setQuaternion(double _angleRan)
{
	geometry_msgs::Quaternion m_quaternion;
	m_quaternion = tf::createQuaternionMsgFromRollPitchYaw(0, 0, _angleRan);
	return m_quaternion;
}



bool getOdomPose(tf::Stamped<tf::Pose>& odom_pose,
                      double& x, double& y, double& yaw,
                      const ros::Time& t, const std::string& base_link)
{
  // Get the robot's pose
  tf::Stamped<tf::Pose> ident (tf::Transform(tf::createIdentityQuaternion(),
                                           tf::Vector3(0,0,0)), t, base_link );
  try
  {
    tf_ = new tf::TransformListener();
    tf_->transformPose(odom_frame_id_, ident, odom_pose);
  }
  catch(tf::TransformException e)
  {
    ROS_WARN("Failed to compute odom pose, skipping scan (%s)", e.what());
    return false;
  }
  x = odom_pose.getOrigin().x();
  y = odom_pose.getOrigin().y();
  double pitch,roll;
  odom_pose.getBasis().getEulerYPR(yaw, pitch, roll);
 
  return true;
}


double computeDistance(geometry_msgs::Point& m_current_point, geometry_msgs::Point& m_goal)
{
	double m_distance;
	m_distance = sqrt(pow(fabs(m_goal.x - m_current_point.x), 2) + pow(fabs(m_goal.y - m_current_point.y), 2));
	return m_distance;
}


int main(int argc, char** argv){
    ros::init(argc, argv, "simple_navigation_goals");
    
    std::vector<geometry_msgs::Pose> pose_list;
    init_goalList(pose_list);

    //tell the action client that we want to spin a thread by default
    MoveBaseClient ac("move_base", true);

    //wait for the action server to come up
    while(!ac.waitForServer(ros::Duration(5.0))){
        ROS_INFO("Waiting for the move_base action server to come up");
    }

    move_base_msgs::MoveBaseGoal goal;

    //we'll send a goal to the robot to move 1 meter forward
    //goal.target_pose.header.frame_id = "base_link";
    goal.target_pose.header.frame_id = "map";
    goal.target_pose.header.stamp = ros::Time::now();
    goal.target_pose.pose = pose_list[count];

    ROS_INFO("Sending goal");
    ac.sendGoal(goal);
    while (ros::ok())
	{
		distance = computeDistance(odom_pose, goal.target_pose.pose.position);
		//ROS_INFO("distance = %f", distance);

		if (distance <= 0.4)
		{
			count++;
			if (10 == count)
			{
				count = 0;
			}

			//Use the map frame to define goal poses
			goal.target_pose.header.frame_id = "map";

			//Set the time stamp to "now"
			goal.target_pose.header.stamp = ros::Time::now();

			//Set the goal pose to the i-th waypoint
			goal.target_pose.pose = pose_list[count];

			ac.sendGoal(goal);
		}

		loop_rate.sleep();
	}

    

    // ac.waitForResult();

    // if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
    //     ROS_INFO("Hooray, the base moved 1 meter forward");
    // else
    //     ROS_INFO("The base failed to move forward 1 meter for some reason");

    // return 0;
}
